import React from 'react';
import {Search, } from '@material-ui/icons';  
import "./topbar.css"

const Topbar = () => {
    return (
        <div style={{position:"sticky", top:"0"}}>
            <div className="topbarContainer">
                <div className="topbarLeft"> 
                    <span className="logo">ShivTalk</span>
                </div>
                <div className="topbarCenter"> 
                    <div className="searchbar">
                        <Search className="searchIcon" />
                        <input placeholder="Search for friend, post or video" type="" className="searchInput" />
                    </div>
                </div>
                <div className="topbarRight"> 
                    <div className="topbarLinks">
                        <span className="topbarLink">Homepage</span>
                        <span className="topbarLink">Timeline</span>
                    </div>

                    
                    <img className="topbarImg" src="/assets/person/1.jpeg" alt="" />
                </div>
            </div>
        </div>
    );
}

export default Topbar