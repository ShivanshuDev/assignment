import React from 'react';
import "./sidebar.css";
import { Users } from '../../dummyData';
import CloseFriend from '../closeFriend/CloseFriend';

export default function Sidebar() {
   
    return (
        <div className="sidebar">
            <div className="sidebarWrapper">
               
                <hr className="sidebarHr"/>
                <ul className="sidebarFriendList"> 
                   {Users.map(u=>(
                       <CloseFriend key={u.id} style={{cursor:"pointer"}} user={u} />
                   ))}
                </ul>
            </div>
        </div>
    )
}
